<?php
return [
  'ticketPrice' => 1000,
];
