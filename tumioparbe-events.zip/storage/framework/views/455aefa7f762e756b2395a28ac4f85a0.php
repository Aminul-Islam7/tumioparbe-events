<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <main class="box">
    <h2 class="box-title">Event Registration</h2>
    <p class="action-text">Confirm your seats now!</p>
    <form class="needs-validation" action="<?php echo e(url('/bkash/create-payment')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <div class="mb-4 required">
        <label for="name-field" class="form-label">Name</label>
        <input type="text" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name-field" name="name"
          placeholder="Shamima Akter" value="<?php echo e(old('name')); ?>" required>
        <div lang="bn" class="invalid-feedback">
          নামটি সঠিক ভাবে লিখুন।
        </div>
        <div id="nameHelp" lang="bn" class="form-text">ইংরেজিতে আপনার নাম লিখুন।</div>
      </div>
      <div class="mb-4 required">
        <label for="phone-field" class="form-label">Contact Number</label>
        <div class="input-group has-validation">
          <span class="input-group-text" id="addon">+88</span>
          <input type="number" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone-field" name="phone"
            placeholder="01XXXXXXXXX" value="<?php echo e(old('phone')); ?>" required>
          <div lang="bn" class="invalid-feedback">
            ফোন নম্বরটি সঠিক নয়।
          </div>
        </div>
        <div id="phoneHelp" lang="bn" class="form-text">আপনার ১১-ডিজিটের ফোন নম্বর লিখুন।</div>
      </div>
      <div class="mb-4">
        <label for="district-field" class="form-label">District</label>
        <input type="text" class="form-control" id="district-field" name="district" placeholder="Dhaka"
          value="<?php echo e(old('district')); ?>">
        <div lang="bn" class="invalid-feedback">
          জেলার নামটি সঠিক ভাবে লিখুন।
        </div>
        <div id="districtHelp" lang="bn" class="form-text">আপনি কোন জেলায় থাকেন?</div>
      </div>

      <div class="mb-4 required">

        <input type="hidden" id="ticket-price" value="<?php echo e(config('settings.ticketPrice')); ?>">

        <div id="ticket-input">
          <label for="tickets-field" class="form-label">Tickets:</label>
          <input type="number" <?php $__errorArgs = ['tickets'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> style="border: 2px solid #DC3534" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> id="tickets-field"
            name="tickets" value="<?php echo e(old('tickets', '2')); ?>" min="1" required>
          <button type="button" id="increment"><i class="fa-solid fa-plus"></i></button>
          <button type="button" id="decrement"><i class="fa-solid fa-minus"></i></button>
          <p class="ticket-price">
            
            ৳ <span id="totalPrice"></span>
          </p>
        </div>
        <?php $__errorArgs = ['tickets'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div lang="bn" class="mt-1" style="color:#DC3534;font-size:14px"> <?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        <div id="districtHelp" lang="bn" class="form-text">আপনি কয়টি সিট বুক করতে চান?</div>
      </div>



      <button type="submit" id="pay-button" class="btn">
        <img src="<?php echo e(asset('images/bkash-logo.png')); ?>" alt="bkash">
        Pay now
        <i class="fa-solid fa-angle-right"></i>
      </button>
    </form>
  </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH D:\1Drives\Aminul Islam\OneDrive\Projects\tumioparbe-events\resources\views/registrations/create.blade.php ENDPATH**/ ?>