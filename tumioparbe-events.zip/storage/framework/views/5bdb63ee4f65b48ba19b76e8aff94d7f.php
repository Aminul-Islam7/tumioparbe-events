<script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>

<script>
  $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            }
        });
  
  $('#search').on('keyup', function(e) {
    e.preventDefault();
    let value = $(this).val();
    $.ajax({
      method: 'GET',
      url: '<?php echo e(route("search-entry")); ?>',
      data: {
        'search_string': value
      },
      success: function(data) {
        $('#data-rows').html(data);
      }
    });
  });
</script><?php /**PATH D:\1Drives\Aminul Islam\OneDrive\Projects\tumioparbe-events\resources\views/search_js.blade.php ENDPATH**/ ?>