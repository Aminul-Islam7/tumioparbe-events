<section id="table">

    <div class="table-head">
        <div class="title">
            <h2>Registrations <span>(<?php echo e($count); ?>)</span></h2>
            <p>Seats Booked: <?php echo e($totalTickets); ?></p>
        </div>
        <div class="fund">
            <p>Fund Received:</p>
            <p class="stars">•••••••</p>
            <p class="hidden-text invisible">৳ <?php echo e($totalFund); ?></p>
            <button class="visibility-btn">
                <i class="fa-regular fa-eye-slash eye"></i>
            </button>
        </div>
        <div class="search">
            <input type="text" id="search" placeholder="Search">
        </div>

    </div>
    <hr>
    <div class="table-body">
        <div class="row head">
            <div class="cell c1">Reg No.</div>
            <div class="cell c2">Name</div>
            <div class="cell c3">Seats</div>
            <div class="cell c4 hide">Contact No.</div>
            <div class="cell c5 hide">District</div>
            <div class="cell c6 hide">
                Amount Paid
                <p class="small">Date - Time</p>
            </div>
            <div class="cell c7 hide">
                bKash No.
                <p class="small">Transaction ID</p>
            </div>
        </div>
        <div class="search" id="data-rows">
            <?php if (isset($component)) { $__componentOriginal2408b8aeecbc961d0deff8a37d070973 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2408b8aeecbc961d0deff8a37d070973 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search-rows','data' => ['entries' => $entries,'count' => $count,'totalTickets' => $totalTickets]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search-rows'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['entries' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($entries),'count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($count),'totalTickets' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalTickets)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2408b8aeecbc961d0deff8a37d070973)): ?>
<?php $attributes = $__attributesOriginal2408b8aeecbc961d0deff8a37d070973; ?>
<?php unset($__attributesOriginal2408b8aeecbc961d0deff8a37d070973); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2408b8aeecbc961d0deff8a37d070973)): ?>
<?php $component = $__componentOriginal2408b8aeecbc961d0deff8a37d070973; ?>
<?php unset($__componentOriginal2408b8aeecbc961d0deff8a37d070973); ?>
<?php endif; ?>
        </div>
    </div>
    <div class="table-foot">

    </div>
</section><?php /**PATH D:\1Drives\Aminul Islam\OneDrive\Projects\tumioparbe-events\resources\views/components/registrations.blade.php ENDPATH**/ ?>