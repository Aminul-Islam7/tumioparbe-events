<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-xl sm:rounded-lg">
                
                <?php if (isset($component)) { $__componentOriginal762932e8d469bc746c05b63b7c4d33b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal762932e8d469bc746c05b63b7c4d33b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.registrations','data' => ['entries' => $registrations,'count' => $count,'totalTickets' => $totalTickets,'totalFund' => $totalFund]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('registrations'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['entries' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($registrations),'count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($count),'totalTickets' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalTickets),'totalFund' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalFund)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal762932e8d469bc746c05b63b7c4d33b9)): ?>
<?php $attributes = $__attributesOriginal762932e8d469bc746c05b63b7c4d33b9; ?>
<?php unset($__attributesOriginal762932e8d469bc746c05b63b7c4d33b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal762932e8d469bc746c05b63b7c4d33b9)): ?>
<?php $component = $__componentOriginal762932e8d469bc746c05b63b7c4d33b9; ?>
<?php unset($__componentOriginal762932e8d469bc746c05b63b7c4d33b9); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\1Drives\Aminul Islam\OneDrive\Projects\tumioparbe-events\resources\views/registrations/index.blade.php ENDPATH**/ ?>