<?php if (isset($component)) { $__componentOriginal2408b8aeecbc961d0deff8a37d070973 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2408b8aeecbc961d0deff8a37d070973 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search-rows','data' => ['entries' => $registrations,'count' => $count,'totalTickets' => $totalTickets]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search-rows'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['entries' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($registrations),'count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($count),'totalTickets' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalTickets)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2408b8aeecbc961d0deff8a37d070973)): ?>
<?php $attributes = $__attributesOriginal2408b8aeecbc961d0deff8a37d070973; ?>
<?php unset($__attributesOriginal2408b8aeecbc961d0deff8a37d070973); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2408b8aeecbc961d0deff8a37d070973)): ?>
<?php $component = $__componentOriginal2408b8aeecbc961d0deff8a37d070973; ?>
<?php unset($__componentOriginal2408b8aeecbc961d0deff8a37d070973); ?>
<?php endif; ?><?php /**PATH D:\1Drives\Aminul Islam\OneDrive\Projects\tumioparbe-events\resources\views/registrations/search.blade.php ENDPATH**/ ?>