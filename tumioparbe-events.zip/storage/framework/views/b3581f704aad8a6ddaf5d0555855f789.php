<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\1Drives\Aminul Islam\OneDrive\Projects\tumioparbe-events\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>