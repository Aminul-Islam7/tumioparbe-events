<?php if(!$count): ?> <div class="row">
  <div class="cell">No entries found</div>
</div>
<?php else: ?>
<?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if (! (is_null($entry->reg_no))): ?>
<div class="row">
  <div class="cell c1"><?php echo e($entry->reg_no); ?></div>
  <div class="cell c2">
    <a href="tel:+88<?php echo e($entry->phone); ?>">
      <?php echo e($entry->name); ?>

    </a>
  </div>
  <div class="cell c3"><?php echo e($entry->tickets); ?></div>
  <div class="cell c4 hide">
    <a href="tel:+88<?php echo e($entry->phone); ?>">
      <?php echo e($entry->phone); ?>

    </a>
  </div>
  <div class=" cell c5 hide"><?php echo e($entry->district); ?>

  </div>
  <div class="cell c6 hide">
    ৳ <?php echo e($entry->amount); ?>

    <p class="small"><?php echo e($entry->created_at->setTimezone('GMT+6')->format('d M Y - h:i A')); ?></p>
  </div>
  <div class="cell c7 hide">
    <?php echo e($entry->bkash_number); ?>

    <p class="small"><?php echo e($entry->trx_id); ?></p>
  </div>
  
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH D:\1Drives\Aminul Islam\OneDrive\Projects\tumioparbe-events\resources\views/components/search-rows.blade.php ENDPATH**/ ?>