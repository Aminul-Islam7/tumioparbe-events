<?php

use Rakibhstu\Banglanumber\NumberToBangla;

$numTo = new NumberToBangla();

$seats = $numTo->bnNum($tickets);

?>

<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  <main class="box">
    <h2 class="box-title">Registration Successful!</h2>
    <p class="action-text">Transaction ID: <?php echo e($trxID); ?></p>

    <div class="info">
      <p lang="bn" class="info-text">
        ধন্যবাদ।
        <br>
        আমরা আপনার পেমেন্ট রিসিভ করেছি।
        <br>
        আপনাদের জন্য <strong><?php echo e($seats); ?> টি সিট</strong> বরাদ্দ করা হয়েছে।
      </p>

      <p class="reg-num">
        Registration No: <?php echo e($regNo); ?>

      </p>

      <p lang="bn" class="info-text">
        রেজিস্ট্রেশান নম্বরটি সংরক্ষণ করুন। এটি আপনাকে SMS এর মাধ্যমেও পাঠিয়ে দেওয়া হবে।
      </p>
    </div>

  </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\1Drives\Aminul Islam\OneDrive\Projects\tumioparbe-events\resources\views/registrations/success.blade.php ENDPATH**/ ?>