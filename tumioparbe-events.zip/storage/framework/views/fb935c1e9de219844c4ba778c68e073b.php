<?php echo e($slot); ?>

<?php /**PATH D:\1Drives\Aminul Islam\OneDrive\Projects\tumioparbe-events\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>